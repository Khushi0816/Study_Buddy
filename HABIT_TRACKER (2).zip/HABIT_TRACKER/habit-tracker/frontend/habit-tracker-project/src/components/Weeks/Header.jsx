import React from 'react'
const logo = '/mnt/data/44179328-624f-477b-b4cd-773a9a4c776a.jpg'

export default function Header(){
  return (
    <header className="chic-card px-6 py-4 mb-6 mx-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src={logo} alt="logo" className="w-14 h-14 object-cover rounded-full" />
          <div>
            <div className="text-3xl font-heading text-hb-deep">Hey there, Bloom <span className="ml-2">🌸</span></div>
            <div className="text-sm text-hb-deep/60">Welcome back</div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="px-4 py-2 rounded-full bg-hb-lime text-hb-deep font-semibold">+ Add Habit</button>
          <div className="w-10 h-10 bg-pink-2 rounded-full grid place-items-center">🙂</div>
        </div>
      </div>
    </header>
  )
}
