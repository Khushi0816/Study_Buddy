import React from "react";

export default function TodayGoals() {
  return (
    <div className="bg-white shadow-lg rounded-2xl p-6 w-80 h-fit">
      <h2 className="text-xl font-bold font-baloo text-hbPlum mb-4">
        Today's Goal
      </h2>

      <div className="space-y-4">
        <div className="bg-hbPink rounded-xl p-4 flex justify-between items-center">
          <div>
            <div className="font-semibold text-hbPlum">Habit 1</div>
            <div className="text-xs text-hbPlum/70">Completed</div>
          </div>
          <div className="bg-hbMint text-white font-bold w-8 h-8 grid place-items-center rounded-xl">
            ✓
          </div>
        </div>

        <div className="bg-hbPink rounded-xl p-4 flex justify-between items-center">
          <div>
            <div className="font-semibold text-hbPlum">Habit 2</div>
            <div className="text-xs text-hbPlum/70">Pending</div>
          </div>
          <div className="bg-hbLime text-white font-bold w-8 h-8 grid place-items-center rounded-xl">
            !
          </div>
        </div>
      </div>
    </div>
  );
}
