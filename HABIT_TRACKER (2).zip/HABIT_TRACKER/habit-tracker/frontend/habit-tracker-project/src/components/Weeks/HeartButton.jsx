import React from "react";
import heartFilled from "../../assets/heart.png";
import brokenHeart from "../../assets/broken-heart.png";

export default function HeartButton({ state, onChange }) {
  const handleClick = () => {
    const next = (state + 1) % 3; // 0 → 1 → 2 → 0
    onChange(next);
  };

  let icon = null;
  if (state === 1) icon = heartFilled;
  if (state === 2) icon = brokenHeart;

  return (
    <button className="heart-btn" onClick={handleClick}>
      {icon && <img src={icon} alt="heart" />}
    </button>
  );
}
