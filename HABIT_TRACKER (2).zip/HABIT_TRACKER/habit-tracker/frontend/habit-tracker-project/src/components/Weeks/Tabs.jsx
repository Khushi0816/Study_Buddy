import React from "react";
import heartFilled from "../../assets/heart.png";
import brokenHeart from "../../assets/broken-heart.png";

export default function HeartButton({ state, onChange }) {
  const handleClick = () => {
    const next = (state + 1) % 3;
    onChange(next);
  };

  let icon = null;

  if (state === 1) icon = heartFilled;       // full heart
  if (state === 2) icon = brokenHeart;       // broken heart

  return (
    <button
      onClick={handleClick}
      className="w-12 h-12 rounded-xl bg-hbPink flex items-center justify-center
                 shadow-sm hover:scale-105 transition"
    >
      {icon && (
        <img
          src={icon}
          alt="heart"
          className="w-6 h-6 object-contain"
        />
      )}
    </button>
  );
}
