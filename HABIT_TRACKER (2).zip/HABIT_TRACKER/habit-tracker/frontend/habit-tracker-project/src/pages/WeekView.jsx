import React, { useState } from "react";
import Header from "../components/Weeks/Header";
import HeartButton from "../components/Weeks/HeartButton";

export default function WeekView() {
  const habits = [
    { id: 1, title: "Habit 1" },
    { id: 2, title: "Habit 2" },
    { id: 3, title: "Habit 3" },
    { id: 4, title: "Habit 4" },
  ];

  const [state, setState] = useState(() => {
    const init = {};
    habits.forEach((h) => (init[h.id] = Array(7).fill(0)));
    return init;
  });

  const updateState = (hid, index, next) => {
    setState((prev) => {
      const copy = { ...prev };
      copy[hid] = [...copy[hid]];
      copy[hid][index] = next;
      return copy;
    });
  };

  return (
    <div>
      <Header />

      <div className="container">
        <div className="days-row">
          {["Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"].map((day) => (
            <div key={day}>{day}</div>
          ))}
        </div>

        {habits.map((h) => (
          <div key={h.id} className="habit-row">
            <div className="habit-title">{h.title}</div>

            <div className="habit-grid">
              {state[h.id].map((value, i) => (
                <HeartButton
                  key={i}
                  state={value}
                  onChange={(next) => updateState(h.id, i, next)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
